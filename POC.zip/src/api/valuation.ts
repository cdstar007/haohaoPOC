/**
 * 估價頁 API
 */

import { get } from './client';
import { API_ENDPOINTS } from '../constants/api';
import { generateMockRichPrice, mockDelay } from './mock';
import type {
  RichPriceResponse,
  RichPrice,
  ValuationYear,
  PriceRange,
} from '../models';

// 是否使用 Mock 資料
const USE_MOCK = true;

/**
 * 取得合理價資料
 * @param stockId 股票代號
 */
export const fetchRichPrice = async (stockId: string): Promise<RichPrice> => {
  if (USE_MOCK) {
    await mockDelay(400);
    const response = generateMockRichPrice(stockId);
    const data = response.data;

    return {
      stockId: data.stockId,
      dividendMethod: {
        oneYear: data.dividendMethod.oneYear,
        threeYear: data.dividendMethod.threeYear,
        fiveYear: data.dividendMethod.fiveYear,
        tenYear: data.dividendMethod.tenYear,
      },
      closingPrices: data.closingPrices.map((item) => ({
        date: item.date,
        price: item.price,
      })),
    };
  }

  const response = await get<RichPriceResponse>(API_ENDPOINTS.richPrice, {
    stock_id: stockId,
  });

  const data = response.data;

  return {
    stockId: data.stockId,
    dividendMethod: {
      oneYear: data.dividendMethod.oneYear,
      threeYear: data.dividendMethod.threeYear,
      fiveYear: data.dividendMethod.fiveYear,
      tenYear: data.dividendMethod.tenYear,
    },
    closingPrices: data.closingPrices.map((item) => ({
      date: item.date,
      price: item.price,
    })),
  };
};

/**
 * 根據年份取得價格區間
 */
export const getPriceRangeByYear = (
  richPrice: RichPrice,
  year: ValuationYear
): PriceRange => {
  switch (year) {
    case 1:
      return richPrice.dividendMethod.oneYear;
    case 3:
      return richPrice.dividendMethod.threeYear;
    case 5:
      return richPrice.dividendMethod.fiveYear;
    case 10:
      return richPrice.dividendMethod.tenYear;
    default:
      return richPrice.dividendMethod.oneYear;
  }
};
