/**
 * API 客戶端
 * 封裝 axios，處理環境切換、通用參數、錯誤處理
 */

import axios, { AxiosInstance, AxiosRequestConfig, AxiosResponse } from 'axios';
import {
  BASE_URL,
  getDefaultParams,
  API_TIMEOUT,
} from '../constants/api';

/**
 * 建立 Axios 實例
 */
const createAPIClient = (): AxiosInstance => {
  const client = axios.create({
    baseURL: BASE_URL,
    timeout: API_TIMEOUT,
    headers: {
      'Content-Type': 'application/json',
      'Accept': 'application/json',
    },
  });

  // 請求攔截器 - 附加通用參數
  client.interceptors.request.use(
    (config) => {
      const defaultParams = getDefaultParams();
      
      // 合併預設參數與請求參數
      config.params = {
        ...defaultParams,
        ...config.params,
      };

      console.log(`[API Request] ${config.method?.toUpperCase()} ${config.url}`, config.params);
      return config;
    },
    (error) => {
      console.error('[API Request Error]', error);
      return Promise.reject(error);
    }
  );

  // 回應攔截器 - 統一處理回應格式 { data: ... }
  client.interceptors.response.use(
    (response: AxiosResponse) => {
      console.log(`[API Response] ${response.config.url}`, response.status);
      
      // API 回應格式為 { data: ... }
      // 直接回傳 response.data 讓上層處理
      return response;
    },
    (error) => {
      console.error('[API Response Error]', error.message);
      
      // 統一錯誤處理
      const errorMessage = error.response?.data?.message || error.message || '發生錯誤';
      const statusCode = error.response?.status;
      
      console.error(`[API Error ${statusCode}]`, errorMessage);
      
      return Promise.reject({
        message: errorMessage,
        status: statusCode,
        originalError: error,
      });
    }
  );

  return client;
};

/**
 * API 客戶端實例
 */
export const apiClient = createAPIClient();

/**
 * 封裝 GET 請求
 */
export const get = async <T>(url: string, params?: Record<string, unknown>): Promise<T> => {
  const response = await apiClient.get<{ data: T }>(url, { params });
  return response.data.data;
};

/**
 * 封裝 POST 請求
 */
export const post = async <T>(url: string, data?: unknown, config?: AxiosRequestConfig): Promise<T> => {
  const response = await apiClient.post<{ data: T }>(url, data, config);
  return response.data.data;
};

/**
 * 封裝多個並行請求
 * 使用 Promise.allSettled 確保部分失敗不影響其他請求
 */
export const parallelRequests = async <T extends Record<string, Promise<unknown>>>(
  requests: T
): Promise<{ [K in keyof T]: Awaited<T[K]> | null }> => {
  const entries = Object.entries(requests);
  const promises = entries.map(([, promise]) => promise);
  const results = await Promise.allSettled(promises);

  const settledResults = {} as { [K in keyof T]: Awaited<T[K]> | null };

  entries.forEach(([key], index) => {
    const result = results[index];
    if (result.status === 'fulfilled') {
      settledResults[key as keyof T] = result.value as Awaited<T[keyof T]>;
    } else {
      console.error(`[Parallel Request Failed] ${key}:`, result.reason);
      settledResults[key as keyof T] = null;
    }
  });

  return settledResults;
};
